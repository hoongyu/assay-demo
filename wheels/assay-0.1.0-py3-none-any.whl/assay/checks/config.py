"""关节体检的全部阈值。默认值在考卷 A 的开发集上定，测试集只用来报成绩。"""

from __future__ import annotations

from dataclasses import dataclass


class NotApplicable(Exception):
    """缺了某种数据，这条规则查不了；记进 not_checked，不当成通过。"""


def reason(exc: Exception) -> str:
    """查不了的原因。用它而不用 str(exc)：原因是 types.Bi 时，str() 会把英文丢掉。"""
    return exc.args[0] if exc.args and isinstance(exc.args[0], str) else str(exc)


@dataclass(frozen=True)
class CheckConfig:
    # 速度单位是「每秒走过本条示范里该关节活动幅度的几分之几」
    still_rate: float = 0.02  # 低于它算没动
    pause_s: float = 3.0  # 中途连续不动超过这么久，算停顿过长
    min_duration_s: float = 1.0  # 短于它，硬规则判过短
    max_gap_factor: float = 1.5  # 相邻时间戳间隔超过 factor/fps，算丢帧
    extra_factor: float = 2.0  # 路程超过同任务中位数这么多倍，算多余动作
    # 「没做完」两个参数 2026-10-03 在加了双臂的开发集上选（scripts/tune_exam_a.py truncate_end）：每个数据集原样报出
    # 不超过 5% 的前提下定位对的最多。(3.0, 0.1) 和 (6.0, 0.05) 打平，取下限大的。
    end_pose_max: float = 3.0  # 收尾姿态离同任务中位收尾姿态，超过收尾常见出入（四分位距）的这么多倍，算没做完
    end_pose_floor: float = 0.1  # 收尾常见出入至少按关节活动幅度的这么多算，免得一批太齐时一点小差别被放大
    end_spread_max: float = 0.15  # 同任务收尾位置普遍散开超过活动幅度的这么多，收尾本来就不固定，不查
    empty_max: float = 0.2  # 离开头姿态最远不到同任务中位数的这么多，算空录
    min_task_episodes: int = 5  # 同任务少于这么多条，不做同任务比较
    video_slack_frames: float = 1.5  # 视频时长和关节数据差超过这么多帧，算两路对不上
    # 「二次抓取」2026-10-04 加，见 docs/superpowers/specs/2026-10-04-regrasp-design.md
    grip_band: float = 0.15  # 夹爪读数按参照批 5 到 95 分位归一化：低于 0.5-band 算合、高于 0.5+band 算开（借 Loop-Engineering-for-VLA，没调）
    # 在一档里至少待这么久才算换档。2026-10-04 第一版没有这条，乐高块（考卷 A 测试集）上放手时一闪张大（2 到 4 帧）
    # 被数成多开合一回；按动作常识定 0.2 秒（采集员张开再合上，一下至少零点几秒），看过的真重抓停了 10、12 帧。
    # RoboVAD train 和两个开发集上 0.1、0.2 秒和不加一样，0.3 秒少检出一条。
    grip_dwell_s: float = 0.2
    regrasp_quantile: float = 0.75  # 参照批开合次数的这个分位当「常见上限」
    # 下面两个 2026-10-04 在 RoboVAD train 上选（results/exam_b_regrasp_train.json）：正常示范最多报出 5% 的前提下，
    # 抓空和掉落检出最多。主臂、从臂在余量 0、1 时都检出 48/60、正常报出 0/307，从臂 AUC 0.903 比主臂 0.890 高；
    # 余量 0 和 1 打平，取大的。加最短停留之前（*_v1.json）选的也是这两个。
    regrasp_margin: int = 1  # 开合次数超过「常见上限 + 这么多」才报
    regrasp_source: str = "state"  # 夹爪读主臂（action）还是从臂（state）
    # 「动作不流畅」「速度过快」2026-10-05 加，见 docs/superpowers/specs/2026-10-05-motion-quality-design.md。
    # 下面五个先验定、不调：一下犹豫零点几秒（「停顿过长」是 3 秒）；0.1 秒滤掉单帧的速度毛刺。
    stop_s: float = 0.3  # 中途速度低于 still_rate 连续这么久，算停了一回
    burst_low: float = 0.2  # 动作段：速度从同任务常见最快速度（各条速度 95 分位的中位数）的这么多以下
    burst_high: float = 0.5  # 升到这么多以上，算一段
    burst_dwell_s: float = 0.1  # 动作段数时，在一档里待不到这么久又回去的一趟不算
    motion_quantile: float = 0.75  # 停顿回数、动作段数取参照那批的这个分位当「常见上限」
    # 下面两个 2026-10-05 在考卷 C 开发集上选（results/exam_c_dev.json）：阈值取成功示范开发集每个数据集报出都不超过 5%
    # 的最小格点（被 armnet 卡在 1.7，27/869）；平顺度的三个候选（中途停顿、动作段数、jerk）在 RoboMIND 上都反着报
    # （AUC 0.31 到 0.45），按规矩选时长基线：检出 40/261、同任务其他原因报出 31/549，差几乎全在 UR 单臂。
    # 「速度过快」的候选在开发集上一条没检出、反倒报出其他原因 7%，不加规则。
    jerky_candidate: str = "duration"  # 动作不流畅看哪个候选（MOTION_CANDIDATES 里的 jerky 类）
    jerky_threshold: float = 1.7  # 比值候选是倍数，次数候选是余量
